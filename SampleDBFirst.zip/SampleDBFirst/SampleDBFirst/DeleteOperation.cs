﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleDBFirst
{
    public partial class DeleteOperation : Form
    {
        public DeleteOperation()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChennaiTraining_21DecEntities context = new ChennaiTraining_21DecEntities();
            bool chkid;
            int stdid;
            chkid = Int32.TryParse(textBox1.Text, out stdid);
            if (!chkid) MessageBox.Show("Enter a valid input");

            Student deletestudent = context.Students.FirstOrDefault(s => s.StudentId ==stdid );
            if (deletestudent != null)
            {
                context.Students.Remove(deletestudent);
                context.SaveChanges();
                MessageBox.Show("Student Record Deleted");
            }
            else MessageBox.Show("Student Id not found!!");

        }
    }
}