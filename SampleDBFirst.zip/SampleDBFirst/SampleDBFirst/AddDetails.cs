﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleDBFirst
{
    public partial class AddDetails : Form
    {
        public AddDetails()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChennaiTraining_21DecEntities context = new ChennaiTraining_21DecEntities();
            Student newStudent = new Student();
            newStudent.StudentName = textBox1.Text;
            newStudent.StudentEmail = textBox3.Text;
            newStudent.StudentDept = textBox2.Text;
            newStudent.StudentGrade = textBox4.Text;
            context.Students.Add(newStudent);
            context.SaveChanges();
            MessageBox.Show("Record Added", "Student");
        }
    }
}
