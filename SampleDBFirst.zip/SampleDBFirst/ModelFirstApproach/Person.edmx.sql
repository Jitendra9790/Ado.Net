  
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 02/10/2017 10:30:44
-- Generated from EDMX file: D:\Lab8\M3Samples\SampleDBFirst\ModelFirstApproach\Person.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [master];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'PersonDetails'
CREATE TABLE [dbo].[PersonDetails] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [PersonName] nvarchar(max)  NOT NULL,
    [ContactDetail_Mobile] bigint  NOT NULL,
    [ContactDetail_Email] nvarchar(max)  NOT NULL,
    [ContactDetail_AlternateMobile] bigint  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'PersonDetails'
ALTER TABLE [dbo].[PersonDetails]
ADD CONSTRAINT [PK_PersonDetails]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------