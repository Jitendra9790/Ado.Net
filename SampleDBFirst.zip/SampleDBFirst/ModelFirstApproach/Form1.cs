﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ModelFirstApproach
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PersonContainer context = new PersonContainer();
            PersonDetail newPerson = new PersonDetail();
            newPerson.PersonName = "Sangeetha";
            newPerson.ContactDetail.Mobile = 9876543221;
            newPerson.ContactDetail.Email = "sangeetha.c@cg.com";
            newPerson.ContactDetail.AlternateMobile = 98788232232;
            context.PersonDetails.Add(newPerson);
            context.SaveChanges();
            MessageBox.Show("Details Added");

        }
    }
}
