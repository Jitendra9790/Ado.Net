﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleDB_First
{
    public partial class DisplayProducts : Form
    {
        public DisplayProducts()
        {
            InitializeComponent();
        }
        ProductContext contextObj;
        private void DisplayProducts_Load(object sender, EventArgs e)
        {
           contextObj = new ProductContext();
            var queryProducts = from prod in contextObj.Products
                                select prod;
            productGrid.DataSource = queryProducts.ToList<Product>();
            gbProduct.Visible = false;

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            contextObj = new ProductContext();

            // Check whether the input is in the expected format
            bool chkInput;
            int pId;
            chkInput = Int32.TryParse(txtProdId.Text, out pId);
            if (!chkInput) { MessageBox.Show("Please enter a valid input"); }
            

                //Method1
                var searchedProduct = from prod in contextObj.Products
                                      where prod.ProductId == pId
                                      select prod;
                //Method 2
                var search2 = contextObj.Products.FirstOrDefault(p => p.ProductId == pId);
                Product pr = new SampleDB_First.Product();
                pr = (Product)search2;
                if (pr != null)
                {
                    MessageBox.Show("Product Found");
                    gbProduct.Visible = true;
                    txtPName.Text = pr.ProductName;
                    txtDesc.Text = pr.Description;
                    txtPrice.Text = pr.UnitPrice.ToString();
                    txtStock.Text = pr.Stock.ToString();

                }
                else { MessageBox.Show("Product does not Found"); }

                //List<Product> myProduct = searchedProduct.ToList<Product>();
                //if (myProduct.Count > 0)
                //{
                //    MessageBox.Show("Product Found");
                //    gbProduct.Visible = true;
                //    txtPName.Text = myProduct[0].ProductName;
                //    txtDesc.Text = myProduct[0].Description;
                //    txtPrice.Text = myProduct[0].UnitPrice.ToString();
                //    txtStock.Text = myProduct[0].Stock.ToString();
                //}
                //else { MessageBox.Show("Product does not Found"); }

            
        }

        private void button1_Click(object sender, EventArgs e)
        {
             contextObj = new SampleDB_First.ProductContext();
            int pId = Convert.ToInt32(txtProdId.Text);
            var search2 = contextObj.Products.FirstOrDefault(p => p.ProductId == pId);
            Product newProduct = new SampleDB_First.Product();
            newProduct = (Product) search2;
            // Updating details into Product
           
            newProduct.ProductName = txtPName.Text;
            newProduct.Description = txtDesc.Text;
            newProduct.UnitPrice = Convert.ToDecimal(txtPrice.Text);
            newProduct.Stock = Convert.ToInt32(txtStock.Text);
           //updating the associated Product table in the Database
           
            contextObj.SaveChanges();
            MessageBox.Show("Product Updated");
            ClearAllText();

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            contextObj = new SampleDB_First.ProductContext();
            int pId = Convert.ToInt32(txtProdId.Text);
            var search2 = contextObj.Products.FirstOrDefault(p => p.ProductId == pId);
            Product oldProduct = new SampleDB_First.Product();
            oldProduct = (Product)search2;
            if (oldProduct != null)
            {
                contextObj.Products.Remove(oldProduct);
                contextObj.SaveChanges();
                MessageBox.Show("Product Deleted");
                ClearAllText();
            }
            else
            {
                MessageBox.Show("Product does not exist or already deleted");
            }

        }

        public  void ClearAllText()
        {
            txtPName.Text = string.Empty;
            txtStock.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtDesc.Clear();
        }

    }
}
