﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleDB_First
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Entities entityObject = new SampleDB_First.Entities();
            var query = from person in entityObject.People
                        select person;

            dataGridView1.DataSource = query.ToList<Person>();


        }
    }
}
