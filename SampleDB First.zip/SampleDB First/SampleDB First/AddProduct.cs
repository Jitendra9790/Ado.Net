﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleDB_First
{
    public partial class AddProduct : Form
    {
        public AddProduct()
        {
            InitializeComponent();
        }

        private void AddProduct_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the '_14MarBLR_Lab5DataSet.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this._14MarBLR_Lab5DataSet.Category);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ProductContext objContext = new SampleDB_First.ProductContext();

            // Inserting details into Product
            Product newProduct = new SampleDB_First.Product();
            newProduct.ProductName = txtPName.Text;
            newProduct.Description = txtDesc.Text;
            newProduct.UnitPrice = Convert.ToDecimal(txtPrice.Text);
            newProduct.Stock = Convert.ToInt32(txtStock.Text);
            newProduct.Category = Convert.ToInt32(comboBox1.SelectedValue);

            //updating the associated Product table in the Database
            objContext.Products.Add(newProduct);
            objContext.SaveChanges();
            MessageBox.Show("New Product Added");




        }
    }
}
