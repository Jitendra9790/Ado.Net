﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProductException
{
    public class PMSException:ApplicationException 

    {

        public PMSException() : base() { }
        public PMSException(string errormsg):base(errormsg) { }


    }
}
