﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Configuration;
using Entity;// Adding reference to the Entity class - Product
using ProductException;// Adding reference to the Exception class

namespace ProductDataAccessLayer
{
    /// <summary>
    /// Class to perform Data operations like Add,Retrieve
    /// </summary>
    public class ProductOperations
    {
        static SqlConnection conTraining;

        static ProductOperations()
        {
            conTraining = new SqlConnection();
            conTraining.ConnectionString =@"Data Source=10.125.6.71\sqlilearn;Initial Catalog=Training_4Feb_chennai;User ID=sqluser;password=sqluser" ;//ConfigurationManager.ConnectionStrings["productConnection"].ConnectionString;
        }

        /// <summary>
        /// To Add a new Product into the Product Table
        /// Author:Sangeetha C
        /// Date Created:28-Mar-2016
        /// Date Modified:
        /// </summary>
        /// <param name="newproduct"></param>
        /// <returns>bool</returns>

        public static bool AddProductDAL(Product newproduct)
        {
            bool productAdded = false;
            try
            {
                conTraining.Open();
                SqlCommand cmdAddProduct = new SqlCommand();
                cmdAddProduct.Connection = conTraining;
                cmdAddProduct.CommandType = CommandType.StoredProcedure;
                cmdAddProduct.CommandText = "group3.usp_insertProduct";

                SqlParameter[] paramProduct = new SqlParameter[3];

                paramProduct[0] = new SqlParameter("@pName", SqlDbType.NVarChar, 50);
                paramProduct[0].Direction = ParameterDirection.Input;
                paramProduct[0].Value = newproduct.ProductName;
                cmdAddProduct.Parameters.Add(paramProduct[0]);

                paramProduct[1] = new SqlParameter("@price", SqlDbType.Money);
                paramProduct[1].Direction = ParameterDirection.Input;
                paramProduct[1].Value = newproduct.Price;
                cmdAddProduct.Parameters.Add(paramProduct[1]);

                paramProduct[2] = new SqlParameter("@categoryId", SqlDbType.Int);
                paramProduct[2].Direction = ParameterDirection.Input;
                paramProduct[2].Value = newproduct.CategoryId;
                cmdAddProduct.Parameters.Add(paramProduct[2]);

                //param = cmdAddProduct.CreateParameter();
                //param.ParameterName = "@categoryId";
                //param.SqlDbType = SqlDbType.Int32 ;
                //param.Value = newproduct.CategoryId;
                //cmdAddProduct.Parameters.Add(param);

                int affectedRows = cmdAddProduct.ExecuteNonQuery();// DataConnection.ExecuteNonQueryCommand(cmdAddProduct);


                if (affectedRows > 0)
                    productAdded = true;
            }

            catch (PMSException)
            { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            { throw; }

            finally { 
                if(conTraining.State==ConnectionState.Open )
                conTraining.Close(); 
            
            }

            return productAdded;

        }
        /// <summary>
        /// Method to read data from table and load in List
        /// </summary>
        /// <returns>List<Product></returns>

        public static List<Product> ShowAllProductsDAL()
        {
            List<Product> productList = null;
            try
            {
                conTraining.Open();
                SqlCommand cmdshowProduct = conTraining.CreateCommand();
                cmdshowProduct.CommandText = "group3.usp_showAllProducts";
                cmdshowProduct.CommandType = CommandType.StoredProcedure;
                SqlDataReader readerProduct = null;
                readerProduct = cmdshowProduct.ExecuteReader();

                DataTable productTable = new DataTable();
                //Load the Data into the table from the Datareader.
                productTable.Load(readerProduct);
                if (productTable.Rows.Count > 0)
                {
                    productList = new List<Product>();
                    foreach (DataRow row in productTable.Rows)
                    {
                        Product product = new Product();
                        product.ProductID = Convert.ToInt32(row["productId"]);
                        product.ProductName = row["product_name"].ToString();
                        product.Price = row["price"].ToString();
                        product.CategoryId = Convert.ToInt32(row["categoryID"]);
                        productList.Add(product);
                    }

                }
                else throw new PMSException("No Records Found");
            }
            catch (PMSException)
            { throw; }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            { throw ex; }
            finally
            {
                conTraining.Close();
            }
            return productList;
        }

        /// <summary>
        /// Method to retrieve the Identity 
        /// 
        /// </summary>
        /// <returns>int</returns>

        public static int GetNextProductID_DAL()
        {
            int nxtid;
            try
            {
                conTraining.Open();
                SqlCommand command = conTraining.CreateCommand();
                command.CommandText = "[group3].[usp_IDENTITY]";
                nxtid = Convert.ToInt32(command.ExecuteScalar());
            }
            catch (PMSException)
            { throw; }
            catch (SqlException e)
            { throw e; }
            finally { conTraining.Close(); }
            return nxtid;

        }

    }
}
