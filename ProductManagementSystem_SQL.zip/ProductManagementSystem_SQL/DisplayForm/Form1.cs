﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Security;
namespace DisplayForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
 SecureString securePassword = new SecureString();
        //private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    try
        //    {
        //        securePassword.AppendChar(e.KeyChar);
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        private void Form1_Load(object sender, EventArgs e)
        { try
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["SecureConnString"].ConnectionString))
                {
                    securePassword.MakeReadOnly();
                    SqlCredential credentials = new SqlCredential(, securePassword);
                    conn.Credential = credentials;
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("Select * From Categories", conn);
                    SqlDataReader reader = cmd.ExecuteReader();
                    DataTable table = new DataTable();
                    table.Load(reader);
        }
    }
}
