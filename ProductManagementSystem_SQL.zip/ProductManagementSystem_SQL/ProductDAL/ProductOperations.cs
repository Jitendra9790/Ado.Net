﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Common;
//using System.Data.SqlClient;
using System.Configuration;
using Entity;// Adding reference to the Entity class - Product
using ProductException;// Adding reference to the Exception class

namespace ProductDAL
{
    /// <summary>
    /// Class to perform Data operations like Add,Retrieve
    /// </summary>
 public   class ProductOperations
    {
      
     /// <summary>
     /// To Add a new Product into the Product Table
     /// Author:Sangeetha C
     /// Date Created:28-Mar-2016
     /// Date Modified:
     /// </summary>
     /// <param name="newproduct"></param>
     /// <returns>bool</returns>

        public static bool AddProductDAL(Product newproduct)
        {
            bool productAdded = false;
            try
            {
                DbCommand cmdAddProduct = DataConnection.CreateCommand();
               cmdAddProduct.CommandText = "group3.usp_insertProduct";

                DbParameter paramProduct = cmdAddProduct.CreateParameter();

                paramProduct.ParameterName="@pName";
                paramProduct.DbType= DbType.String ;
                paramProduct.Value = newproduct.ProductName;
                cmdAddProduct.Parameters.Add(paramProduct);

                paramProduct = cmdAddProduct.CreateParameter();
                paramProduct .ParameterName="@price";
                paramProduct.DbType=DbType.Currency ;
              //  paramProduct.Direction = ParameterDirection.Input;
                paramProduct.Value = newproduct.Price;
                cmdAddProduct.Parameters.Add(paramProduct);


                paramProduct = cmdAddProduct.CreateParameter();
                paramProduct.ParameterName = "@categoryId";
                paramProduct.DbType = DbType.Int32;
                paramProduct.Value = newproduct.CategoryId;
                cmdAddProduct.Parameters.Add(paramProduct);

           int affectedRows= DataConnection.ExecuteNonQueryCommand(cmdAddProduct);


                if (affectedRows > 0)
                    productAdded = true;
            }

            catch (PMSException)
            { throw; }
            catch (DbException)
            {
                throw;
            }
            catch (Exception )
            { throw ; }
                
                
                
            return productAdded;

        }
     /// <summary>
     /// Method to read data from table and load in List
     /// </summary>
     /// <returns>List<Product></returns>

        public static List<Product > ShowAllProductsDAL()
        {
            List<Product> productList = null;
            try
            {
                DbCommand cmdshowProduct = DataConnection .CreateCommand();
                cmdshowProduct.CommandText = "group3.usp_showAllProducts";

                DataTable productTable = new DataTable();
                productTable =DataConnection .ExecuteSelectCommand(cmdshowProduct);

               
                if (productTable.Rows.Count > 0)
                {
                    productList = new List<Product>();
                    foreach (DataRow row in productTable.Rows)
                    {
                        Product product = new Product();
                        product.ProductID = (Int32 )row["productId"];
                        product.ProductName = row["product_name"].ToString();
                        product.Price = row["price"].ToString();
                        product.CategoryId = (Int32 )row["categoryID"];
                        productList.Add(product);
                    }

                }
                else throw new PMSException("No Records Found");
            }
            catch (PMSException)
            { throw; }
            catch (DbException )
            {
                throw ;
            }
            catch (SystemException )
            { throw ; }
           
            return productList;
        }

     /// <summary>
     /// Method to retrieve the Identity 
     /// 
     /// </summary>
     /// <returns>int</returns>

        public static int GetNextProductID_DAL()
               
        {
            int nxtid;
            try
            {
                DbCommand command = DataConnection .CreateCommand();
                command.CommandText = "[group3].[usp_IDENTITY]";
                nxtid = Convert.ToInt32(DataConnection.ExecuteScalarCommand(command));
            }
            catch (PMSException)
            { throw; }
            catch (DbException )
            { throw ; }
                return nxtid;
        
        }

    }
}
