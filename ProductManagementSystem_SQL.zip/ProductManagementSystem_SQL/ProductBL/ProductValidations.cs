﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions ;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Entity;
using ProductException;
using ProductDAL;
//using ProductDataAccessLayer;

namespace ProductBL
{
    /// <summary>
    /// BL class for Validating the Data and thereby calling the DAL methods
    /// </summary>
    public class ProductValidations
    {
        /// <summary>
        /// To Validate the Product 
        /// </summary>
        /// <param name="product"></param>
        /// <returns>bool</returns>
        private static bool ValidateProduct(Product product)
        {

            bool validproduct = true;
            StringBuilder message = new StringBuilder();
            
            if (!(Regex.IsMatch(product.ProductName, @"^[A-Za-z]+$")))
            {
                validproduct = false;
                message.Append(Environment.NewLine + "ProductName must contain Characters only");
            }
           
            if (!(Regex.IsMatch(product.Price.ToString(), @"^[0-9]+$")))
            {
                validproduct = false;
                message.Append(Environment.NewLine + "Product Price must contain digits only");
            }

            if ((product.Price.ToString().Equals(string.Empty)))
            {
                validproduct = false;
                message.Append(Environment.NewLine + "Product Price is Required");
            }
            if ((product.ProductName.Length == 0) || (product.Price.ToString().Length == 0) || (Convert.ToInt32(product .Price) <= 0))
            {
                validproduct = false;
                message.Append(Environment.NewLine + " All fields are Required");
           
            }

            if (validproduct == false)
            {
                throw new PMSException(message.ToString());
            }
            return validproduct;
        }

        /// <summary>
        /// To validate the Product and to add the Product to Collection List by 
        /// calling the AddProduct method of DAL
        /// </summary>
        /// <param name="product"></param>
        /// <returns>Bool</returns>
        public static bool AddProductBL(Product product)
        {
            bool productadded = false;
            try
            {
                if (ValidateProduct(product))
                {
                    productadded = ProductOperations.AddProductDAL(product);

                }
            }
            catch (PMSException e)
            { throw e; }
            return productadded;
        }
        /// <summary>
        /// Function to Display all products from Collection
        /// </summary>
        /// <returns>List<Product></returns>
        public static List<Product> DisplayAllProductBL()
        {
            List<Product> plist = new List<Product>();
            try
            {
                plist = ProductOperations.ShowAllProductsDAL();
                if (plist == null)
                    throw new PMSException("No Product Found");
            }
            catch (PMSException p)
            {
                throw p;
            }
            catch (SqlException e)
            {
                throw e;
            }
            return plist; // Returns the list of Products

        }
        public static int GetProductID_BL()
        {
            try
            {
                return ProductOperations.GetNextProductID_DAL();
            }
            catch (SqlException e)
            { throw e; }
        }







    }
}
