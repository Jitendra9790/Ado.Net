﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CustomerDetails_StreamReaderWriter
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi A. Wani
    /// Description : This class is to demonstrate File Stream Reader Writer Operations
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //Create a file to write data 
                FileStream fs = new FileStream("CustomerDetails.txt", FileMode.Create, FileAccess.Write);
                //Write data using Stream writer
                StreamWriter sw = new StreamWriter(fs);
                //Input data 
                sw.WriteLine("This are Customer details for the year 2015-2016. Most of our Customers are from east zone");
                sw.Flush();      //clears buffer for the current writer
                fs.Close();      // close file and release resources


                //Open file to read data
                fs = new FileStream("CustomerDetails.txt", FileMode.Open, FileAccess.Read);
                //Read data using stream reader
                StreamReader sr = new StreamReader(fs);

                //Display data on console window  
                Console.WriteLine(sr.ReadToEnd());
                fs.Close();  // close file and release resources

            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException se)
            {
                Console.WriteLine(se.Message);
            }
            Console.ReadKey();
        }
    }
}
