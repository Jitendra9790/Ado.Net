﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SJA.Entity;      //Reference to Salesman Entity
using SJA.Exception;    //Reference to Salesman Exception
using SJA.DAL;          //Reference to Salesman Data Access Layer

namespace SJA.BL
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi A. Wani
    /// Description : This class will have buisness logic for Salesman 
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    public class SalesmanValidations
    {

        //Method to validate Salesman details
        public static bool ValidateSalesman(Salesman sal)
        {
            bool isValidated = true;

            StringBuilder message = new StringBuilder();

            try
            {
                //Checking Salesman code that it should be 4 digits
                if (sal.SalesmanCode < 1000 || sal.SalesmanCode > 9999)
                {
                    message.Append("Salesman Code should be 4 digits long\n");
                    isValidated = false;
                }

                //Checking Salesman name
                if (sal.SalesmanName == string.Empty)
                {
                    message.Append("Salesman Name should be provided\n");
                    isValidated = false;
                }

                //Checking Region
                if (sal.SalesmanRegion.ToUpper() != "EAST" && sal.SalesmanRegion.ToUpper() != "WEST" && sal.SalesmanRegion.ToUpper() != "NORTH" && sal.SalesmanRegion.ToUpper() != "SOUTH")
                {
                    message.Append("Region should be either East or West or North or South\n");
                    isValidated = false;
                }

                if (isValidated == false)
                    throw new SalesmanException(message.ToString());
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isValidated;
        }


        //Method to add new Salesman
        public static bool AddSalesman(Salesman sal)
        {
            bool isAdded = false;

            try
            {
                //Validating Salesman details
                if (ValidateSalesman(sal))
                {
                    //Adding the Salesman by calling DAL Add method
                    isAdded = SalesmanOperations.AddSalesman(sal);
                }
                else
                    throw new SalesmanException("Please provide valid Salesman details");
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isAdded;
        }

        //Method to search Salesman
        public static Salesman SearchSalesman(int salCode)
        {
            Salesman sal = null;

            try
            {
                //Searching salesman by calling DAL search method
                sal = SalesmanOperations.SearchSalesman(salCode);
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return sal;
        }

        //Method to serialize Salesman details
        public static bool SerializeSalesman()
        {
            bool isSerialized = false;

            try
            {
                //Serializing by calling DAL serialize method
                isSerialized = SalesmanOperations.SerializeSalesman();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return isSerialized;
        }

        //Method to Deserialize Salesman
        public static List<Salesman> DeserializeSalesman()
        {
            List<Salesman> salesmanList = null;

            try
            {
                //deserializing Salesman by calling DAL deserialize method
                salesmanList = SalesmanOperations.DeserializeSalesman();
            }
            catch (SalesmanException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return salesmanList;
        }

    }
}
