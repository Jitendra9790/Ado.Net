﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace SJA.Entity
{
    /// <summary>
    /// Employee ID : 161616
    /// Employee Name : Rashmi A. Wani
    /// Description : This is an Entity Class for Salesman details
    /// Date of Modification : 8th Oct 2018
    /// </summary>
    [Serializable]
    public class Salesman
    {
        //Get or Set Salesman Code
        public int SalesmanCode { get; set; }

        //Get or Set Salesman Name
        public string SalesmanName { get; set; }

        //Get or Set Region
        public string SalesmanRegion { get; set; }

        //Get or Set Salesman Target 
        public int SalesmanTarget { get; set; }

        //Get or Set Salesman actual sales
        public int S_ActualSales { get; set; }

    }
}
