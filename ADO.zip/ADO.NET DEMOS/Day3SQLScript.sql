CREATE TABLE Student
(
     StudentID int PRIMARY KEY,
     StudentName varchar(30),
     Mobile bigint,
     Email varchar(75)
)

INSERT INTO Student
VALUES(1,'Amit',9953412789,'amit@yahoo.com')

INSERT INTO Student
VALUES(2,'Manoj',9851243678,'manoj@gmail.com')

INSERT INTO Student
VALUES(3,'Ketaki',7724136541,'ketaki@rediffmail.com')

INSERT INTO Student
VALUES(4,'Sanjana',8876214534,'sanjana@live.in')
