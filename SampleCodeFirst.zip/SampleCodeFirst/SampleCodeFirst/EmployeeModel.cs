namespace SampleCodeFirst
{
    using System;
    using System.Data.Entity;
    using System.Linq;
    using System.ComponentModel.DataAnnotations;
    public class EmployeeModel : DbContext
    {
        // Your context has been configured to use a 'EmployeeModel' connection string from your application's 
        // configuration file (App.config or Web.config). By default, this connection string targets the 
        // 'SampleCodeFirst.EmployeeModel' database on your LocalDb instance. 
        // 
        // If you wish to target a different database and/or database provider, modify the 'EmployeeModel' 
        // connection string in the application configuration file.
        public EmployeeModel()
            : base("name=EmployeeModel")
        {
        }

        // Add a DbSet for each entity type that you want to include in your model. For more information 
        // on configuring and using a Code First model, see http://go.microsoft.com/fwlink/?LinkId=390109.

         public virtual DbSet<Employee_CS> CSEmployees { get; set; }
    }

    public class Employee_CS
    {
        [Key]
        public int EmployeeId { get; set; }
        [Required]
     //   [RegularExpression("[A-Z][a-z]{3,10}")]
        public string EmployeeName { get; set; }
        [Required]
     
        public DateTime EmployeeDOJ { get; set; }
        public string EmployeeDept { get; set; }
        public string Designation { get; set; }

    }
}