﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleCodeFirst
{
    public partial class EmployeeForm : Form
    {
        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAddEmp_Click(object sender, EventArgs e)
        {
            EMSModel  empContext = new SampleCodeFirst.EMSModel();

            SampleEmp_CS newEmp = new SampleCodeFirst.SampleEmp_CS();
            newEmp.EmpName = txtEName.Text;
            newEmp.Designation = txtDesig.Text;
            newEmp.EmployeeDOJ = DateTime.Parse(txtDOJ.Text);
            newEmp.EmployeeDept = cbDept.SelectedItem.ToString();
            try
            {
                empContext.SampleEmployees.Add(newEmp);
                empContext.SaveChanges();
                MessageBox.Show("New Employee Details added");
            }
            catch (Exception ex)
            {

                MessageBox.Show("An Error occured : " + ex.Message);
            }
           

        }
    }
}
