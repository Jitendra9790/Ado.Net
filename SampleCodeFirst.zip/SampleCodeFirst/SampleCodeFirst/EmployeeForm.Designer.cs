﻿namespace SampleCodeFirst
{
    partial class EmployeeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbProduct = new System.Windows.Forms.GroupBox();
            this.btnAddEmp = new System.Windows.Forms.Button();
            this.cbDept = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDOJ = new System.Windows.Forms.TextBox();
            this.txtDesig = new System.Windows.Forms.TextBox();
            this.txtEName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.gbProduct.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbProduct
            // 
            this.gbProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gbProduct.Controls.Add(this.btnAddEmp);
            this.gbProduct.Controls.Add(this.cbDept);
            this.gbProduct.Controls.Add(this.label1);
            this.gbProduct.Controls.Add(this.txtDOJ);
            this.gbProduct.Controls.Add(this.txtDesig);
            this.gbProduct.Controls.Add(this.txtEName);
            this.gbProduct.Controls.Add(this.label4);
            this.gbProduct.Controls.Add(this.label3);
            this.gbProduct.Controls.Add(this.label2);
            this.gbProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbProduct.Location = new System.Drawing.Point(229, 46);
            this.gbProduct.Name = "gbProduct";
            this.gbProduct.Size = new System.Drawing.Size(544, 511);
            this.gbProduct.TabIndex = 6;
            this.gbProduct.TabStop = false;
            this.gbProduct.Text = "Add New Employee Details ";
            // 
            // btnAddEmp
            // 
            this.btnAddEmp.Location = new System.Drawing.Point(94, 324);
            this.btnAddEmp.Name = "btnAddEmp";
            this.btnAddEmp.Size = new System.Drawing.Size(346, 64);
            this.btnAddEmp.TabIndex = 10;
            this.btnAddEmp.Text = "Add New Employee";
            this.btnAddEmp.UseVisualStyleBackColor = true;
            this.btnAddEmp.Click += new System.EventHandler(this.btnAddEmp_Click);
            // 
            // cbDept
            // 
            this.cbDept.DisplayMember = "CategoryName";
            this.cbDept.FormattingEnabled = true;
            this.cbDept.Items.AddRange(new object[] {
            "Admin",
            "Finance",
            "HR",
            "IT",
            "LnD"});
            this.cbDept.Location = new System.Drawing.Point(261, 244);
            this.cbDept.Name = "cbDept";
            this.cbDept.Size = new System.Drawing.Size(256, 37);
            this.cbDept.TabIndex = 9;
            this.cbDept.ValueMember = "CategoryId";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 247);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 29);
            this.label1.TabIndex = 8;
            this.label1.Text = "Department";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtDOJ
            // 
            this.txtDOJ.Location = new System.Drawing.Point(261, 183);
            this.txtDOJ.Name = "txtDOJ";
            this.txtDOJ.Size = new System.Drawing.Size(256, 35);
            this.txtDOJ.TabIndex = 6;
            // 
            // txtDesig
            // 
            this.txtDesig.Location = new System.Drawing.Point(261, 120);
            this.txtDesig.Name = "txtDesig";
            this.txtDesig.Size = new System.Drawing.Size(256, 35);
            this.txtDesig.TabIndex = 5;
            // 
            // txtEName
            // 
            this.txtEName.Location = new System.Drawing.Point(261, 54);
            this.txtEName.Name = "txtEName";
            this.txtEName.Size = new System.Drawing.Size(256, 35);
            this.txtEName.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 29);
            this.label4.TabIndex = 2;
            this.label4.Text = "Date Of Joining";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 29);
            this.label3.TabIndex = 1;
            this.label3.Text = "Designation";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 29);
            this.label2.TabIndex = 0;
            this.label2.Text = "Employee Name";
            // 
            // EmployeeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 611);
            this.Controls.Add(this.gbProduct);
            this.Name = "EmployeeForm";
            this.Text = "EmployeeForm";
            this.gbProduct.ResumeLayout(false);
            this.gbProduct.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbProduct;
        private System.Windows.Forms.Button btnAddEmp;
        private System.Windows.Forms.ComboBox cbDept;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDOJ;
        private System.Windows.Forms.TextBox txtDesig;
        private System.Windows.Forms.TextBox txtEName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}