﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AllPatDBFirst
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// Author:Viraj Dere
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //Display Event
        private void button_Display_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities contextObj = new AllPatDBFirst.Sep19CHNEntities();

                //Query to display patient from Maharashtra
                var query = from Patient pat in contextObj.Patients
                            where pat.PState == "Maharashtra"
                            select pat;

                //Creating List to Display
                List<Patient> eList = new List<AllPatDBFirst.Patient>();
                eList = query.ToList<Patient>();

                if (eList.Count <= 0)
                {
                    MessageBox.Show("No records found!");
                }
                //Displaying Data in DataGrid
                grid_Display.ItemsSource = query.ToList<Patient>();
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
        }

    }
}
