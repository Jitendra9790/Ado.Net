﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Exception
{
    /// <summary>
    /// Description : The class for raising Patient specific exceptions
    /// Date of Creation : 10/17/2018
    /// </summary>
    public class PatientException : ApplicationException
    {
        //Default constructor
        public PatientException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public PatientException(string Message) : base(Message)
        { }
    }
}
