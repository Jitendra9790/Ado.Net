﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Entity
{
    /// <summary>
    /// Description : This is entity class for the Patient information
    /// Date of Creation : 10/17/2018
    /// </summary>
    public class Patient
    {
        //Get Set Relevant patient Information
        public int PatientId { get; set; }
        public string PFname { get; set; }
        public string PLastName { get; set; }
        public string PGender { get; set; }
        public string PAddress { get; set; }
        public string PCity { get; set; }
        public string PState { get; set; }
        public long PPincode { get; set; }
        public long PPhone { get; set; }
        
    }
}
