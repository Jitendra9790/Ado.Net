use Sep19CHN

create table Viraj.Patient
(
PId int identity(1000,1) primary key,
PFirstName varchar(20),
PLastName varchar(20),
PGender varchar(20),
PAddress varchar(100),
PCity varchar(20),
PState varchar(20),
PPincode bigint,
PPhoneNumber bigint,
)

insert into Viraj.Patient values('Priya','Dingorkar','Female','Abc st.142,Wakad','Pune','Maharashtra',411039,7845411052)
insert into Viraj.Patient values('Carla','Joyce','Female','152St.avenue,New York','New York','Washington',885025,7785201210)
insert into Viraj.Patient values('Maya','Bejoice','Female','New Port,152St,Washington','DC','Washington',454120,8856525121)


 create proc Viraj.usp_Addpatient
 @pFname varchar(20),
 @pLname varchar(20),
 @pGender varchar(20),
 @pAddress varchar(20),
 @pCity varchar(20),
 @pState varchar(20),
 @pPincode bigint,
 @pPhone bigint
 AS
 BEGIN
 insert into Viraj.Patient values(@pFname,@pLname, @pGender ,@pAddress ,@pCity, @pState ,@pPincode ,@pPhone )
 END


 create proc Viraj.usp_DisplayPatient
 AS
 BEGIN
 select * from Viraj.Patient 
 END  

 select * from Viraj.Patient
 delete from Viraj.Patient where PId=1002


 create table Viraj.Gender
(
DeptId int primary key,
DeptName varchar(30),
)

DBCC CHECKIDENT ('Viraj.Patient', RESEED, 0);
GO

select IDENT_CURRENT('Viraj.patient')+ident_incr('Viraj.patient')